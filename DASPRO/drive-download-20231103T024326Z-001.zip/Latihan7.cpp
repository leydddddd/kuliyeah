#include <iostream>

using namespace std;

int main()
{
    string str1;
    string str2;

    cout<<"Masukkan String 1 = "<<endl;
    cin>>str1;
    cout<<"Masukkan String 2 = "<<endl;
    cin>>str2;

    string str3 = str1 + str2;
    cout<<"Hasil Penggabungan String 1 dan 2 = "<<str3<<endl;

    return 0;
}
