This template was created by Namastaii 

Creative Commons License: CC BY 
http://creativecommons.org/licenses/by/3.0/

Placeholder bg image created by Chocolate Berry (licensed under Creative Commons, Attribution-NonCommercial. (CC BY-NC 3.0)), 
found at: http://lemmasoft.renai.us/forums/viewtopic.php?f=52&t=31572#p366401